package com.pdfstudio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

const val NONE = 0
const val HL = 1
const val PEN = 2

/** Annotation stroke; points are normalised (0..1) within the page. */
data class Ink(val page: Int, val kind: Int, val pts: List<Offset>)
data class OcrLine(val text: String, val l: Float, val t: Float, val r: Float, val b: Float)

private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

class PdfSession(ctx: Context, uri: Uri) {
    val file: File = File(ctx.cacheDir, "current.pdf").also { f ->
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    }
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val r = PdfRenderer(pfd)
    val count = r.pageCount

    @Synchronized
    fun render(i: Int, w: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val h = (w.toFloat() * p.height / p.width).toInt()
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            b.eraseColor(AColor.WHITE)
            p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return b
        } finally { p.close() }
    }

    suspend fun lines(i: Int): List<OcrLine> {
        val b = render(i, 1800)
        val t = recognizer.process(InputImage.fromBitmap(b, 0)).await()
        return t.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            l.boundingBox?.let {
                OcrLine(l.text, it.left / b.width.toFloat(), it.top / b.height.toFloat(),
                    it.right / b.width.toFloat(), it.bottom / b.height.toFloat())
            }
        }
    }

    fun close() { runCatching { r.close(); pfd.close() } }
}

suspend fun savePdf(ctx: Context, s: PdfSession, dst: Uri, inks: List<Ink>, ocr: Boolean, progress: (Int) -> Unit) {
    val lines = HashMap<Int, List<OcrLine>>()
    if (ocr) for (i in 0 until s.count) { progress(i + 1); lines[i] = s.lines(i) }
    PDDocument.load(s.file).use { doc ->
        val font = PDType1Font.HELVETICA
        for (i in 0 until doc.numberOfPages) {
            val mine = inks.filter { it.page == i }
            val ol = lines[i].orEmpty()
            if (mine.isEmpty() && ol.isEmpty()) continue
            val page = doc.getPage(i)
            val mb = page.mediaBox
            val w = mb.width
            val h = mb.height
            fun px(x: Float) = mb.lowerLeftX + x * w
            fun py(y: Float) = mb.upperRightY - y * h
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                for (k in mine) {
                    cs.setGraphicsStateParameters(PDExtendedGraphicsState().apply {
                        strokingAlphaConstant = if (k.kind == HL) 0.4f else 1f
                    })
                    if (k.kind == HL) { cs.setStrokingColor(255, 235, 59); cs.setLineWidth(w * 0.03f) }
                    else { cs.setStrokingColor(220, 0, 0); cs.setLineWidth(w * 0.004f) }
                    cs.moveTo(px(k.pts[0].x), py(k.pts[0].y))
                    for (p in k.pts.drop(1)) cs.lineTo(px(p.x), py(p.y))
                    cs.stroke()
                }
                for (l in ol) { // invisible text layer => searchable / copyable PDF
                    val t = l.text.filter { it.code in 32..126 }
                    if (t.isBlank()) continue
                    val fs = ((l.b - l.t) * h).coerceIn(4f, 40f)
                    cs.beginText()
                    cs.setRenderingMode(RenderingMode.NEUTRAL)
                    cs.setFont(font, fs)
                    cs.newLineAtOffset(px(l.l), py(l.b))
                    cs.showText(t)
                    cs.endText()
                }
            }
        }
        ctx.contentResolver.openOutputStream(dst)!!.use { doc.save(it) }
    }
}

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf<Uri?>(null)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        incoming = intent?.data
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { App(incoming) { incoming = it } } }
        }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); incoming = intent.data }
}

@Composable
fun App(doc: Uri?, setDoc: (Uri?) -> Unit) {
    if (doc == null) Browser { setDoc(it) } else Viewer(doc) { setDoc(null) }
}

@Composable
fun Browser(open: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var root by remember { mutableStateOf(prefs.getString("root", null)?.let { DocumentFile.fromTreeUri(ctx, Uri.parse(it)) }) }
    var stack by remember(root) { mutableStateOf(listOfNotNull(root)) }
    var items by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    val pickDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.edit().putString("root", u.toString()).apply()
            root = DocumentFile.fromTreeUri(ctx, u)
        }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) open(u) }
    val cur = stack.lastOrNull()
    LaunchedEffect(cur) {
        items = withContext(Dispatchers.IO) {
            cur?.listFiles()
                ?.filter { it.isDirectory || it.name?.endsWith(".pdf", true) == true }
                ?.sortedWith(compareBy<DocumentFile>({ !it.isDirectory }, { it.name?.lowercase() }))
                ?: emptyList()
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Text("PDF Studio", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pickDir.launch(null) }) { Text(if (root == null) "Choose folder" else "Change folder") }
            OutlinedButton(onClick = { pickFile.launch(arrayOf("application/pdf")) }) { Text("Open PDF") }
        }
        if (stack.size > 1) TextButton(onClick = { stack = stack.dropLast(1) }) { Text("⬅ " + (stack[stack.size - 2].name ?: "")) }
        OutlinedTextField(q, { q = it }, label = { Text("Search in this folder") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyColumn {
            items(items.filter { it.name?.contains(q, true) == true }) { f ->
                Text(
                    (if (f.isDirectory) "📁 " else "📄 ") + f.name,
                    Modifier.fillMaxWidth().clickable { if (f.isDirectory) stack = stack + f else open(f.uri) }.padding(14.dp)
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun Viewer(uri: Uri, close: () -> Unit) {
    val ctx = LocalContext.current
    val res by produceState<Result<PdfSession>?>(null, uri) {
        value = withContext(Dispatchers.IO) { runCatching { PdfSession(ctx, uri) } }
    }
    BackHandler { close() }
    val r = res
    when {
        r == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        r.isFailure -> Column(Modifier.padding(24.dp)) {
            Text("Cannot open this PDF (it may be password protected).")
            Button(onClick = close) { Text("Back") }
        }
        else -> ViewerBody(r.getOrThrow(), close)
    }
}

@Composable
fun ViewerBody(session: PdfSession, close: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    DisposableEffect(session) { onDispose { session.close() } }
    val inks = remember(session) { mutableStateListOf<Ink>() }
    var tool by remember { mutableIntStateOf(NONE) }
    val list = rememberLazyListState()
    var busy by remember { mutableStateOf<String?>(null) }
    var ocrText by remember { mutableStateOf<String?>(null) }
    var wantOcr by remember { mutableStateOf(false) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { dst ->
        if (dst != null) scope.launch {
            busy = "Saving…"
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    savePdf(ctx, session, dst, inks.toList(), wantOcr) { busy = "OCR page $it/${session.count}" }
                }
            }
            busy = null
            Toast.makeText(ctx, if (r.isSuccess) "Saved" else "Save failed: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton(onClick = close) { Text("⬅") }
            ToolBtn("View", tool == NONE) { tool = NONE }
            ToolBtn("Highlight", tool == HL) { tool = HL }
            ToolBtn("Pen", tool == PEN) { tool = PEN }
            TextButton(onClick = { inks.removeLastOrNull() }) { Text("Undo") }
            TextButton(onClick = {
                scope.launch {
                    busy = "Reading text…"
                    val t = runCatching { withContext(Dispatchers.Default) { session.lines(list.firstVisibleItemIndex).joinToString("\n") { it.text } } }
                    busy = null
                    ocrText = t.getOrElse { "OCR failed: ${it.message}" }
                }
            }) { Text("Read text") }
            TextButton(onClick = { wantOcr = false; saver.launch("annotated.pdf") }) { Text("Save") }
            TextButton(onClick = { wantOcr = true; saver.launch("searchable.pdf") }) { Text("OCR + Save") }
        }
        busy?.let { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, Modifier.padding(6.dp)) }
        if (tool != NONE) Text("Drawing mode: switch to View to scroll", Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.labelSmall)
        LazyColumn(state = list, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(session.count) { i -> PageView(session, i, tool, inks) }
        }
    }
    ocrText?.let { t ->
        AlertDialog(
            onDismissRequest = { ocrText = null },
            confirmButton = {
                TextButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ocr", t))
                    ocrText = null
                }) { Text("Copy") }
            },
            dismissButton = { TextButton(onClick = { ocrText = null }) { Text("Close") } },
            text = { Column(Modifier.verticalScroll(rememberScrollState()).heightIn(max = 400.dp)) { Text(if (t.isBlank()) "No text found" else t) } }
        )
    }
}

@Composable
fun ToolBtn(t: String, on: Boolean, f: () -> Unit) {
    if (on) Button(onClick = f) { Text(t) } else OutlinedButton(onClick = f) { Text(t) }
}

@Composable
fun PageView(s: PdfSession, idx: Int, tool: Int, inks: SnapshotStateList<Ink>) {
    var bmp by remember(idx) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    LaunchedEffect(idx) { bmp = withContext(Dispatchers.Default) { s.render(idx, 1080).asImageBitmap() } }
    val b = bmp
    if (b == null) {
        Box(Modifier.fillMaxWidth().height(400.dp), Alignment.Center) { CircularProgressIndicator() }
        return
    }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    Box(
        Modifier.fillMaxWidth().aspectRatio(b.width.toFloat() / b.height).pointerInput(tool) {
            if (tool == NONE) return@pointerInput
            fun n(o: Offset) = Offset((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
            detectDragGestures(
                onDragStart = { cur = listOf(n(it)) },
                onDrag = { ch, _ -> cur = cur + n(ch.position) },
                onDragEnd = { if (cur.size > 1) inks.add(Ink(idx, tool, cur)); cur = emptyList() },
                onDragCancel = { cur = emptyList() }
            )
        }
    ) {
        Image(b, null, Modifier.fillMaxSize())
        Canvas(Modifier.fillMaxSize()) {
            inks.filter { it.page == idx }.forEach { drawInk(it.pts, it.kind) }
            drawInk(cur, tool)
        }
    }
}

fun DrawScope.drawInk(pts: List<Offset>, kind: Int) {
    if (pts.size < 2) return
    val path = Path().apply {
        moveTo(pts[0].x * size.width, pts[0].y * size.height)
        for (p in pts.drop(1)) lineTo(p.x * size.width, p.y * size.height)
    }
    if (kind == HL) drawPath(path, Color(0xFFFFEB3B).copy(alpha = 0.4f), style = Stroke(size.width * 0.03f, cap = StrokeCap.Butt, join = StrokeJoin.Round))
    else drawPath(path, Color(0xFFDC0000), style = Stroke(size.width * 0.004f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}
